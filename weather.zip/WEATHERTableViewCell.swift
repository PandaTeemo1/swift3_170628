//
//  WEATHERTableViewCell.swift
//  SwiftTutorial20170627
//
//  Created by 오라클자바 on 2017. 6. 29..
//  Copyright © 2017년 ParkD. All rights reserved.
//

import UIKit

class WEATHERTableViewCell: UITableViewCell {

    @IBOutlet var dayLabel: UILabel!
    @IBOutlet var hourLabel: UILabel!
    @IBOutlet var tempLabel: UILabel!
    @IBOutlet var wfKorLabel: UILabel!
    @IBOutlet var icon: UIImageView!
    

}
